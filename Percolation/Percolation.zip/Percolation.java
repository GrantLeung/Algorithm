import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;
public class Percolation {
	private boolean[] NN;
	private int N;
	private WeightedQuickUnionUF WQUF;
	private WeightedQuickUnionUF WQUFBack;

	public Percolation(int N){
		this.N = N;
		NN = new boolean[N*N];
		WQUF = new WeightedQuickUnionUF(N*N + 4);
		WQUFBack = new WeightedQuickUnionUF(N*N + 1);
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++){
				NN[i*N+j]=false;
			}
		}
	}	
	public void open(int i,int j){
		if(i<1 || i>N || j<1 || j>N){
			throw new java.lang.IndexOutOfBoundsException();
		}
		int ii = i - 1;
		int jj = j - 1;
		if(NN[ii * N + jj] ){
			return;
		}
		NN[ii * N + jj]=true;
		//the first line
		if(i==1){
			WQUF.union(ii*N+jj,N*N);
			WQUFBack.union(ii*N+jj,N*N);
		}
		//the last line
		if(i==N){
			WQUF.union(ii*N+jj,N*N+1);
		}
		//up
		if((ii-1)>=0 && NN[(ii-1)*N+jj]){
			WQUF.union(ii*N+jj,(ii-1)*N+jj);
			WQUFBack.union(ii*N+jj,(ii-1)*N+jj);
		}
		//left
		if((jj-1)>=0 && NN[ii*N+(jj-1)]){
			WQUF.union(ii*N+jj,ii*N+(jj-1));
			WQUFBack.union(ii*N+jj,ii*N+(jj-1));
		}
		//below
		if((ii+1)<N && NN[(ii+1)*N+jj]){
			WQUF.union(ii*N+jj,(ii+1)*N+jj);
			WQUFBack.union(ii*N+jj,(ii+1)*N+jj);
		}
		//right
		if((jj+1)<N && NN[ii*N+(jj+1)]){
			WQUF.union(ii*N+jj,ii*N+(jj+1));
			WQUFBack.union(ii*N+jj,ii*N+(jj+1));
		}
	}
	
	public boolean isOpen(int i,int j){
		if(i<1 || i>N || j<1 || j>N){
			throw new java.lang.IndexOutOfBoundsException();
		}
		return NN[(i-1)*N+(j-1)];
	}
	
	public boolean isFull(int i,int j){
		if(i<1 || i>N || j<1 || j>N){
			throw new java.lang.IndexOutOfBoundsException();
		}
		return NN[(i-1)*N+(j-1)] && WQUFBack.connected((i-1)*N+(j-1),N*N);
	}
	
	public boolean percolates(){
		return WQUF.connected(N*N,N*N+1);
	}
}