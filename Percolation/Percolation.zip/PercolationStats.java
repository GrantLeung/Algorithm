import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
public class PercolationStats {
	private double mean;
	private double stddev;
	private double confLow;
	private double confUp;
	
	public PercolationStats(int N,int T){
		if(N <= 0 || T <= 0){
			throw new java.lang.IllegalArgumentException();
		}
		double times[] = new double[T];
		for(int t=0;t<T;t++){
			Percolation perc = new Percolation(N);
			for(int a=0;a<N*N;a++){
				int pt = (int) (Math.random() * N * N);
				int i = pt / N + 1;
				int j = pt % N + 1;
				while(perc.isOpen(i, j)){
					pt = (int) (Math.random() * N * N);
					i = pt / N + 1;
					j = pt % N + 1;
				}
				perc.open(i, j);
				if(perc.percolates()){
					times[t] = ((double) a) / (N *N);
					break;
				}
			}
		}
		for (int t = 0; t <T; t++)
			mean += times[t];
		mean /= T;
		
		for (int t = 0; t <T; t++)
			stddev += (times[t] - mean) * (times[t] - mean);
		stddev /= (T - 1);
		stddev = Math.sqrt(stddev);
		
		confLow = mean - 1.96 * stddev / Math.sqrt((double)T);
		confUp = mean + 1.96 * stddev / Math.sqrt((double)T);
	}
	
	public double mean(){
		return mean;
	}
	
	public double stddev(){
		return stddev;
	}
	
	public double confidenceLo(){
		return confLow;
	}
	
	public double confidenceHi(){
		return confUp;
	}
	
	public static void main(String[] args){
		int N = StdIn.readInt();
		int T = StdIn.readInt();
		PercolationStats pers = new PercolationStats(N,T);
		StdOut.println("mean=" + pers.mean());
		StdOut.println("stddev=" + pers.stddev());
		StdOut.println("95% confidence interval=" + pers.confidenceLo() + ", " + pers.confidenceHi());
	}
}